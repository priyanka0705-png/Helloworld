package com.json.wraper;


import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.io.IOUtils;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

//import com.devglan.rsa.RSAEncryption;
import com.json.wraper.JSONObjectWrapper;

import net.sf.jasperreports.engine.util.JsonUtil;


public class RSAEncryption {

    private static String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAmoZJABSYvHuHGdi79GdaxFkyUiczToi4CsCujNrNzBBckD7pnAlq40cCWPbwEw4G5g0SASxc0NZR7q5H/RNTljmUcPzENXvLcYdjGpM8sdHSGVlDgTwStRG1MkvPXj3umHa7L06sXpvfk21ag8j5zNWwvUL6hBZAh9yBuxGqV0h+/+3cxAwznmgMUh4ChKBjO6arWA3mODF+vZUB/iRxGzlbXOPaMSWXB7Ma2gDJj+JbtHARTjMvASqOXCyWgCYh7Srm/xDD5MGtQqnOoEJZqVoPPHA1JfW6fqcIdi/MTjl5EiglpEyf8vcbRRdewGrZZDVySsicmB879ih3NN0BWwIDAQAB";
    private static String privateKey = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCahkkAFJi8e4cZ2Lv0Z1rEWTJSJzNOiLgKwK6M2s3MEFyQPumcCWrjRwJY9vATDgbmDRIBLFzQ1lHurkf9E1OWOZRw/MQ1e8txh2Makzyx0dIZWUOBPBK1EbUyS89ePe6YdrsvTqxem9+TbVqDyPnM1bC9QvqEFkCH3IG7EapXSH7/7dzEDDOeaAxSHgKEoGM7pqtYDeY4MX69lQH+JHEbOVtc49oxJZcHsxraAMmP4lu0cBFOMy8BKo5cLJaAJiHtKub/EMPkwa1Cqc6gQlmpWg88cDUl9bp+pwh2L8xOOXkSKCWkTJ/y9xtFF17AatlkNXJKyJyYHzv2KHc03QFbAgMBAAECggEBAJGgSj3kK0k+VUVbh06+9MCkmxLnVKgHmwKvMhEWx+ov5TwfvkNKcMx+iEzVc81RY9j8qmImr9Y0lQSOhNORmi2yWB3faP5Ki6GTiSdraUDfz9QJ1t99gNfaN1yOK4DSdwCCrMfZqgKDfcHPxgT6q8iJ/sVu0O8YlXo0qqJk9JbKCSbeGzYdKfpUh7Byn+0nIP517djWtNNLAhiaCPUaYucKazvoDDcq4M/0c1om7l3oS5eWWU7uV7A72dWg3J1JQYM1z8swucr8ff6jjqpsU4DuADlnHrfACgityUsLywXadNyhFgUXxPTr/DwP9WPjtEynARFBAwhL6zMyzAKj8zECgYEA03xCp1OF7tqPu7AqYQjk+d2x8WS/07vhR44pinUajjzkSKv0VX57VWpbay8uDO7/lpfsP0sxogeP2sOHvhCvbbLTnPKjYjsxKcc2brlXmO/Tlh2bxFoynma0K1Xwwg2vupSxzQnjm0mcXzXYs1Q1vZx1yG2q1X6wGLE7KEKsVMMCgYEAuwy7ASnYMRQ2R3wnO6LnsvC1s8aHm887dvbM3GVqhzLZYnZMAKIKIau2M1bWqf1Xw+wbbpy/z3TZl2rbUx+FoWuwQ13zYItgTfvYH3QTL7gjiMcxe/q3YGGtsbaVryt/JqaFiuzk5mrrn0xNW3CL979URVyiE6y215IlYz//d4kCgYALhS9UUhZvpnRB8xy74HIoskzpK2XPsOJatYHJywtBSEvfMY7DwXoScxK7yfwmNDa0C16RLBVuEB9j+VbBocMMpLsmR4li5nqNHg73BR2idR3/hWlgztEHE+0olyvgRkKWVVdCJhHB+caM4TAGxMWQqJ855c9yhc4t6imgzdD5ZQKBgBVhUCLC6K47dDTZkRZ0+WzvrKU+5RM/LbncXfA3O2T2v/hMM0XDP8s3eF0H6QOHLLf9Telny1joL1LqaOVobfrUd1JL89yuMbTYO4zk1KiYsJ8avaJBNyKyJ4tvpk5ed2swj4UgrM1VnVcY/qKcC7Omz/gZrYD4NfIQB2v/zbCZAoGAElaXSyyn3gnE6Rt6MMK2H5j4KqMrSzu3BFxnyAsZT2VGBL5BjDAyMdPvJNkSY5vB6GPEE7Csb79pAVLcikPwMYAoPjEOSGkybKwKEkw3HjzhO39KzvWDNEVKyJQxMN776sEnVVEKC/Iq5hMpJkIJMeDoZcIGNr/LxxNBsxm2vXg=";
    
    public static PublicKey getPublicKey(String base64PublicKey){
        PublicKey publicKey = null;
        try{
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            publicKey = keyFactory.generatePublic(keySpec);
            return publicKey;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        return publicKey;
    }

    public static PrivateKey getPrivateKey(String base64PrivateKey){
        PrivateKey privateKey = null;
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64PrivateKey.getBytes()));
        KeyFactory keyFactory = null;
        try {
            keyFactory = KeyFactory.getInstance("RSA");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        try {
            privateKey = keyFactory.generatePrivate(keySpec);
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        return privateKey;
    }
    
    
    	

    public static byte[] encrypt(Object data, String publicKey) throws BadPaddingException, IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
        return cipher.doFinal(data.toString().getBytes());
    }

    public static String decrypt(byte[] data, PrivateKey privateKey) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        return new String(cipher.doFinal(data));
    }

    public static String decrypt(String data, String base64PrivateKey) throws IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
        return decrypt(Base64.getDecoder().decode(data.getBytes()), getPrivateKey(base64PrivateKey));
    }

    public static void main(String[] args) throws IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, BadPaddingException {
        try {
        	Object stringToBeEncrypted= "{ \"lifecycleStatus\": \"string\",\"validFor\": {\"startDateTime\": \"2018-08-23T08:33:44.640Z\",\"endDateTime\": \"2018-08-23T08:33:44.640Z\"	},\"lastUpdate\": \"2018-08-23T08:33:44.640Z\",\"name\": \"IPhone6S\",\"description\": \"IPhone6S\",\"version\": \"6S\"}";

        	try {
        		stringToBeEncrypted = new JSONObjectWrapper(new JSONParser().parse((String) stringToBeEncrypted));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//        	System.out.println("check"+stringToBeEncrypted.toString());
            String encryptedString = Base64.getEncoder().encodeToString(encrypt(stringToBeEncrypted, publicKey));
            System.out.println(encryptedString);
            String decryptedString = RSAEncryption.decrypt(encryptedString, privateKey);
         System.out.println(decryptedString);
        } catch (NoSuchAlgorithmException e) {
            System.err.println(e.getMessage());
        }

    }
    
    
    
}

