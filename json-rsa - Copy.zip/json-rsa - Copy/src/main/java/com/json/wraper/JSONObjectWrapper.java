package com.json.wraper;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

//import RSAEncryption;

//import static org.apache.commons.lang.StringUtils.repeat;
public class JSONObjectWrapper {
	private static final String DEFAULT_VALUE = "******************************";
	private static RSAEncryption rsa;
	private static String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAmoZJABSYvHuHGdi79GdaxFkyUiczToi4CsCujNrNzBBckD7pnAlq40cCWPbwEw4G5g0SASxc0NZR7q5H/RNTljmUcPzENXvLcYdjGpM8sdHSGVlDgTwStRG1MkvPXj3umHa7L06sXpvfk21ag8j5zNWwvUL6hBZAh9yBuxGqV0h+/+3cxAwznmgMUh4ChKBjO6arWA3mODF+vZUB/iRxGzlbXOPaMSWXB7Ma2gDJj+JbtHARTjMvASqOXCyWgCYh7Srm/xDD5MGtQqnOoEJZqVoPPHA1JfW6fqcIdi/MTjl5EiglpEyf8vcbRRdewGrZZDVySsicmB879ih3NN0BWwIDAQAB";
	private final Object jsonObjectWrapped;

	public JSONObjectWrapper(Object jsonObjectWrapped) {
		this.jsonObjectWrapped = jsonObjectWrapped;
     	System.out.println("1"+jsonObjectWrapped.toString());
	}

	private static String anonymiseValue(Object value) throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException, NoSuchPaddingException, NoSuchAlgorithmException {
		int valueLength = String.valueOf(value).length();

		return "\"" + rsa.encrypt(value, publicKey) + "\"";
		
	}

	/**
	 * Convert an object to JSON text.
	 * <p>
	 * If this object is a Map or a List, and it's also a JSONAware, JSONAware will
	 * be considered firstly.
	 * <p>
	 * DO NOT call this method from toJSONString() of a class that implements both
	 * JSONAware and Map or List with "this" as the parameter, use
	 * JSONObject.toJSONString(Map) or JSONArray.toJSONString(List) instead.
	 * 
	 * @see org.json.simple.JSONObject#toJSONString(Map)
	 * @see org.json.simple.JSONArray#toJSONString(List)
	 * 
	 * @param value
	 * @return JSON text, or "null" if value is null or it's an NaN or an INF
	 *         number.
	 * @throws NoSuchAlgorithmException 
	 * @throws NoSuchPaddingException 
	 * @throws IllegalBlockSizeException 
	 * @throws BadPaddingException 
	 * @throws InvalidKeyException 
	 */
	public static String toJSONString(Object value) throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException, NoSuchPaddingException, NoSuchAlgorithmException {
		if (value == null)
			return "null";

		if (value instanceof String)
			return anonymiseValue(value);

		if (value instanceof Double) {
			if (((Double) value).isInfinite() || ((Double) value).isNaN())
				return "null";
			else
				return anonymiseValue(value);
		}

		if (value instanceof Float) {
			if (((Float) value).isInfinite() || ((Float) value).isNaN())
				return "null";
			else
				return anonymiseValue(value);
		}

		if (value instanceof Number)
			return anonymiseValue(value);

		if (value instanceof Boolean)
			return anonymiseValue(value);

		if (value instanceof Map)
			return JSONObjectWrapper.toJSONString((Map) value);

		if (value instanceof List)
			return JSONObjectWrapper.toJSONString((List) value);

		return value.toString();
	}

	/**
	 * Convert a list to JSON text. The result is a JSON array. If this list is also
	 * a JSONAware, JSONAware specific behaviours will be omitted at this top level.
	 * 
	 * @see org.json.simple.JSONValue#toJSONString(Object)
	 * 
	 * @param list
	 * @return JSON text, or "null" if list is null.
	 * @throws NoSuchAlgorithmException 
	 * @throws NoSuchPaddingException 
	 * @throws IllegalBlockSizeException 
	 * @throws BadPaddingException 
	 * @throws InvalidKeyException 
	 */
	public static String toJSONString(List list) throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException, NoSuchPaddingException, NoSuchAlgorithmException {
		if (list == null)
			return "null";

		boolean first = true;
		StringBuffer sb = new StringBuffer();
		Iterator iter = list.iterator();

		sb.append('[');
		while (iter.hasNext()) {
			if (first)
				first = false;
			else
				sb.append(',');

			Object value = iter.next();
			if (value == null) {
				sb.append("null");
				continue;
			}
			sb.append(JSONObjectWrapper.toJSONString(value));
		}
		sb.append(']');
		return sb.toString();
	}

	/**
	 * Convert a map to JSON text. The result is a JSON object. If this map is also
	 * a JSONAware, JSONAware specific behaviours will be omitted at this top level.
	 * 
	 * @see org.json.simple.JSONValue#toJSONString(Object)
	 * 
	 * @param map
	 * @return JSON text, or "null" if map is null.
	 * @throws NoSuchAlgorithmException 
	 * @throws NoSuchPaddingException 
	 * @throws IllegalBlockSizeException 
	 * @throws BadPaddingException 
	 * @throws InvalidKeyException 
	 */
	public static String toJSONString(Map map) throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException, NoSuchPaddingException, NoSuchAlgorithmException {
		if (map == null)
			return "null";

		StringBuffer sb = new StringBuffer();
		boolean first = true;
		Iterator iter = map.entrySet().iterator();

		sb.append('{');
		while (iter.hasNext()) {
			if (first)
				first = false;
			else
				sb.append(',');

			Map.Entry entry = (Map.Entry) iter.next();
			JSONObjectWrapper.toJSONString(String.valueOf(entry.getKey()), entry.getValue(), sb);
		}
		sb.append('}');
		return sb.toString();
	}

	public String toJSONString() throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException, NoSuchPaddingException, NoSuchAlgorithmException {
		return toJSONString(jsonObjectWrapped);
	}

	public String toString() {
		try {
			return toJSONString();
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	private static String toJSONString(String key, Object value, StringBuffer sb) throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException, NoSuchPaddingException, NoSuchAlgorithmException {
		sb.append('\"');
		if (key == null)
			sb.append("null");
		else
			JSONObjectWrapper.escape(key, sb);
		sb.append('\"').append(':');

		sb.append(JSONObjectWrapper.toJSONString(value));

		return sb.toString();
	}

	/**
	 * @param s  - Must not be null.
	 * @param sb
	 */
	static void escape(String s, StringBuffer sb) {
		for (int i = 0; i < s.length(); i++) {
			char ch = s.charAt(i);
			switch (ch) {
			case '"':
				sb.append("\\\"");
				break;
			case '\\':
				sb.append("\\\\");
				break;
			case '\b':
				sb.append("\\b");
				break;
			case '\f':
				sb.append("\\f");
				break;
			case '\n':
				sb.append("\\n");
				break;
			case '\r':
				sb.append("\\r");
				break;
			case '\t':
				sb.append("\\t");
				break;
			case '/':
				sb.append("\\/");
				break;
			default:
				// Reference: http://www.unicode.org/versions/Unicode5.1.0/
				if ((ch >= '\u0000' && ch <= '\u001F') || (ch >= '\u007F' && ch <= '\u009F')
						|| (ch >= '\u2000' && ch <= '\u20FF')) {
					String ss = Integer.toHexString(ch);
					sb.append("\\u");
					for (int k = 0; k < 4 - ss.length(); k++) {
						sb.append('0');
					}
					sb.append(ss.toUpperCase());
				} else {
					sb.append(ch);
				}
			}
		} // for
	}

}
